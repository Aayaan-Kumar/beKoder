from tkinter import *
from tkinter import messagebox
import ast

win = Tk()
win.title("Sign Up")
win.geometry('925x500+300+200')
win.configure(bg= '#fff')
win.resizable(False,False)

def signup():
    username=user.get()
    password=user2.get()
    password2=user2.get()

    if password==password2:
        try:
            file=open('datasheet.txt','r+')
            d=file.read()
            r=ast.literal_eval(d)

            dict2={username:password}
            r.update(dict2)
            file.truncate(0)
            file.close()

            file =open('datasheet.txt', 'w')
            w=file.write(str(r))
            
            messagebox.showinfo('Sign Up','Successfully signed up')

        except:
            file=open('datasheet.txt','w')
            pp=str({'Username':'Password'})
            file.write(pp)
            file.close()

    else:
        messagebox.showerror('Invalid',"Both password should be same")

img = PhotoImage(file='login-page.png')
Label(win,image=img,border=0,bg='#fff').place(x=90, y=50)


frame=Frame(win,width=350,height=390,bg='#fff')
frame.place(x=480,y=50)


heading = Label(frame,text='Sign Up', fg="#57a1f8", bg='white', font=('Microsoft Yahei UI Light', 23, 'bold'))
heading.place(x=100,y=5)


#####--------------------------------------------------------------------


def on_enter(e):
    user.delete(0,'end')

def on_leave(e):
    if user.get()=='':
        user.insert(0,'Username')

user = Entry(frame,width=25,fg = 'black',border=0,bg='white',font=('Microsoft Yahei UI Light',11))
user.place(x=30,y=80)
user.insert(0,'Username')
user.bind('<FocusIn>', on_enter)
user.bind('<FocusOut>', on_leave)

Frame(frame,width=295,height=2,bg='black').place(x=25,y=107)

#####--------------------------------------------------------------------


def on_enter(e):
    user1.delete(0,'end')

def on_leave(e):
    if user1.get()=='':
        user1.insert(0,'Password')

user1 = Entry(frame,width=25,fg = 'black',border=0,bg='white',font=('Microsoft Yahei UI Light',11))
user1.place(x=30,y=150)
user1.insert(0,'Password')
user1.bind('<FocusIn>', on_enter)
user1.bind('<FocusOut>', on_leave)

Frame(frame,width=295,height=2,bg='black').place(x=25,y=177)

#####--------------------------------------------------------------------


def on_enter(e):
    user2.delete(0,'end')

def on_leave(e):
    if user2.get()=='':
        user2.insert(0,'Confirm Password')

user2 = Entry(frame,width=25,fg = 'black',border=0,bg='white',font=('Microsoft Yahei UI Light',11))
user2.place(x=30,y=220)
user2.insert(0,'Confirm Password')
user2.bind('<FocusIn>', on_enter)
user2.bind('<FocusOut>', on_leave)

Frame(frame,width=295,height=2,bg='black').place(x=25,y=247)

#------------------------------------------

Button(frame,width=39,pady=7,text='Sign Up',bg='#57a1f8',fg='white',border=0,command=signup).place(x=35,y=280)
label=Label(frame,text='I have an account',fg='black',bg='white',font=('Microsoft Yahei UI Light',9))
label.place(x=90,y=340)
signin = Button(frame,width=6,text='Sign in',border=0,bg='white',cursor='hand2',fg='#57a1f8')
signin.place(x=200,y=340)


win.mainloop()
